import csv, random, os, math
from datetime import datetime, timedelta
from pathlib import Path

SEED=42
random.seed(SEED)
BASE=Path('/mnt/data/shopsphere_ai_lab')
DATA=BASE/'data'
KB=BASE/'knowledge_base'
IMG=BASE/'product_images'
DATA.mkdir(parents=True,exist_ok=True); KB.mkdir(parents=True,exist_ok=True); IMG.mkdir(parents=True,exist_ok=True)

cities=['Hyderabad','Bengaluru','Mumbai','Delhi','Chennai','Pune','Kolkata','Ahmedabad','Jaipur','Kochi','Vijayawada','Visakhapatnam']
states={'Hyderabad':'TS','Bengaluru':'KA','Mumbai':'MH','Delhi':'DL','Chennai':'TN','Pune':'MH','Kolkata':'WB','Ahmedabad':'GJ','Jaipur':'RJ','Kochi':'KL','Vijayawada':'AP','Visakhapatnam':'AP'}
categories=['Shoes','Apparel','Electronics','Home','Beauty','Sports','Books','Accessories']
brands=['TrailBlaze','UrbanNest','TechNova','FitPulse','CasaCraft','GlowUp','BookBridge','AeroLite','DailyWear','SoundMax']
loyalty=['Bronze','Silver','Gold','Platinum']
channels=['web','android_app','ios_app']
warehouses=['WH_HYD','WH_BLR','WH_MUM','WH_DEL','WH_CHN']
suppliers=['SupplyOne','FastKart Logistics','UrbanSource','GlobalTrade','SouthHub Supplies','NorthStar Imports']

# customers
customers=[]
for i in range(1,1001):
    city=random.choice(cities)
    signup=datetime(2023,1,1)+timedelta(days=random.randint(0,1050))
    app=random.random()<0.62
    tier=random.choices(loyalty,weights=[45,30,18,7])[0]
    age=random.randint(18,65)
    customers.append({
        'customer_id':f'C{i:05d}','age':age,'gender':random.choice(['Female','Male','Other']),
        'city':city,'state':states[city],'signup_date':signup.date().isoformat(),
        'loyalty_tier':tier,'uses_mobile_app':int(app),
        'preferred_channel': random.choice(channels if app else ['web','web','android_app']),
        'marketing_opt_in':int(random.random()<0.72)
    })

# products
products=[]
for i in range(1,501):
    cat=random.choice(categories); brand=random.choice(brands)
    base_price={'Shoes':2500,'Apparel':1200,'Electronics':6500,'Home':1800,'Beauty':900,'Sports':2200,'Books':450,'Accessories':700}[cat]
    price=max(99, round(random.gauss(base_price,base_price*0.35),2))
    rating=round(min(5,max(2.5,random.gauss(4.1,0.45))),1)
    products.append({'product_id':f'P{i:05d}','sku':f'SKU{i:05d}','category':cat,'brand':brand,
        'product_name':f'{brand} {cat} Model {i:03d}','price':price,
        'avg_rating':rating,'launch_date':(datetime(2023,1,1)+timedelta(days=random.randint(0,1050))).date().isoformat(),
        'is_active':int(random.random()<0.94),'image_path':f'product_images/P{i:05d}_clean.png'})

# orders and order_items simplified one row per order item
orders=[]; order_items=[]
start=datetime(2025,1,1)
for oid in range(1,10001):
    cust=random.choice(customers); prod=random.choice(products)
    od=start+timedelta(days=random.randint(0,364), hours=random.randint(0,23), minutes=random.randint(0,59))
    qty=random.choices([1,2,3,4],weights=[72,20,6,2])[0]
    discount=random.choice([0,0,0,5,10,15,20])
    promised=random.choice([2,3,4,5])
    actual=max(1, int(random.gauss(promised+random.choice([-1,0,0,1,2]),1.2)))
    delay=max(0, actual-promised)
    order_value=round(prod['price']*qty*(1-discount/100),2)
    returned=int(random.random() < (0.05 + 0.035*delay + (0.04 if prod['category'] in ['Apparel','Shoes'] else 0)))
    churn_risk=0.18 + 0.08*delay + 0.12*returned + (0.05 if cust['uses_mobile_app']==0 else -0.03)
    orders.append({'order_id':f'O{oid:06d}','customer_id':cust['customer_id'],'order_date':od.isoformat(timespec='minutes'),
        'channel':cust['preferred_channel'],'city':cust['city'],'order_value':order_value,'discount_pct':discount,
        'promised_delivery_days':promised,'actual_delivery_days':actual,'delivery_delay_days':delay,
        'payment_method':random.choice(['UPI','Credit Card','Debit Card','COD','Wallet']),'returned_flag':returned,
        'first_order_flag':0})
    order_items.append({'order_id':f'O{oid:06d}','product_id':prod['product_id'],'sku':prod['sku'],'quantity':qty,
        'unit_price':prod['price'],'discount_pct':discount,'line_value':order_value})
# mark first order per customer
seen=set()
orders.sort(key=lambda x:(x['customer_id'],x['order_date']))
for o in orders:
    if o['customer_id'] not in seen:
        o['first_order_flag']=1; seen.add(o['customer_id'])
orders.sort(key=lambda x:x['order_id'])

# clickstream
clicks=[]; actions=['page_view','search','product_view','add_to_cart','remove_from_cart','checkout_start','purchase','wishlist']
for sid in range(1,30001):
    cust=random.choice(customers); prod=random.choice(products)
    ts=start+timedelta(days=random.randint(0,364), seconds=random.randint(0,86400))
    action=random.choices(actions,weights=[25,16,28,10,3,7,5,6])[0]
    clicks.append({'event_id':f'E{sid:07d}','customer_id':cust['customer_id'],'session_id':f'S{random.randint(1,8000):06d}',
        'event_time':ts.isoformat(timespec='seconds'),'channel':cust['preferred_channel'],'event_type':action,
        'product_id':prod['product_id'],'search_query': random.choice(['running shoes','wireless headphones','cotton shirt','kitchen storage','face serum','yoga mat','laptop bag','']) if action=='search' else '',
        'page_load_ms':max(400,int(random.gauss(1900,700))),'device_type':random.choice(['mobile','desktop','tablet'])})

# reviews and tickets
positive=['great quality','fast delivery','value for money','excellent fit','looks premium','easy to use']
negative=['late delivery','damaged packaging','size runs small','poor quality','wrong item received','refund delayed']
reviews=[]
for rid in range(1,5001):
    order=random.choice(orders); item=next((x for x in order_items if x['order_id']==order['order_id']), random.choice(order_items))
    issue=random.choices(['delivery','quality','size_fit','pricing','packaging','positive'],weights=[18,15,10,8,12,37])[0]
    if issue=='positive':
        rating=random.choice([4,5]); phrase=random.choice(positive); sentiment='positive'
        text=f'{phrase}. I am happy with this product and would buy again.'
    else:
        rating=random.choice([1,2,3]); sentiment='negative' if rating<=2 else 'neutral'
        phrase={'delivery':'late delivery','quality':'poor quality','size_fit':'size runs small','pricing':'price felt high','packaging':'damaged packaging'}[issue]
        text=f'The product had {phrase}. Please improve this experience.'
    reviews.append({'review_id':f'R{rid:06d}','order_id':order['order_id'],'customer_id':order['customer_id'],
        'product_id':item['product_id'],'review_date':(datetime.fromisoformat(order['order_date'])+timedelta(days=random.randint(1,14))).date().isoformat(),
        'rating':rating,'review_text':text,'sentiment_label':sentiment,'issue_category':issue})

tickets=[]
issues=['refund','shipping','damaged_product','account','payment','return_policy','warranty']
for tid in range(1,3001):
    cust=random.choice(customers); issue=random.choices(issues,weights=[20,25,16,9,12,12,6])[0]
    templates={
        'refund':'I want a refund for my order. The amount is not credited yet.',
        'shipping':'My order is delayed and tracking is not updating.',
        'damaged_product':'The item arrived damaged and the packaging was torn.',
        'account':'I cannot login to my account and reset link is not working.',
        'payment':'Payment was deducted but order is not confirmed.',
        'return_policy':'Can I return this product after opening the package?',
        'warranty':'I need warranty support for my product.'}
    urg='high' if issue in ['payment','damaged_product','refund'] and random.random()<0.45 else random.choice(['low','medium','medium','high'])
    tickets.append({'ticket_id':f'T{tid:06d}','customer_id':cust['customer_id'],'created_at':(start+timedelta(days=random.randint(0,364), seconds=random.randint(0,86400))).isoformat(timespec='seconds'),
        'ticket_text':templates[issue],'issue_type':issue,'urgency_label':urg,
        'resolution_time_hours':round(max(0.25, random.gauss(8 if urg=='high' else 18,5)),2),
        'refund_status':random.choice(['not_applicable','pending','approved','rejected']) if issue=='refund' else 'not_applicable'})

# inventory
inventory=[]
for p in products[:300]:
    wh=random.choice(warehouses); stock=random.randint(20,1500); reorder=random.randint(50,300)
    lead=random.randint(3,21); daily=max(1, int(random.gauss(12,8)))
    stockout=int(stock/(daily+1)<14)
    inventory.append({'sku':p['sku'],'product_id':p['product_id'],'warehouse_id':wh,'current_stock':stock,
        'reorder_point':reorder,'supplier':random.choice(suppliers),'supplier_lead_time_days':lead,
        'avg_daily_sales_30d':daily,'stockout_risk_14d':stockout})

# daily sales for LSTM/forecasting
sales=[]
for p in products[:100]:
    base=random.randint(5,35); season=random.random()*10
    for d in range(180):
        date=(datetime(2025,7,1)+timedelta(days=d)).date()
        qty=max(0,int(random.gauss(base + season*math.sin(d/14), max(2,base*0.25))))
        sales.append({'date':date.isoformat(),'sku':p['sku'],'units_sold':qty,'promo_flag':int(random.random()<0.12),'price':p['price']})

def write_csv(name, rows):
    with open(DATA/name,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

for name,rows in [('customers.csv',customers),('products.csv',products),('orders.csv',orders),('order_items.csv',order_items),('clickstream.csv',clicks),('reviews.csv',reviews),('support_tickets.csv',tickets),('inventory.csv',inventory),('daily_sales.csv',sales)]: write_csv(name,rows)

# knowledge base docs
(KB/'return_policy.txt').write_text('ShopSphere Return Policy\nMost products can be returned within 30 days of delivery. Sale items can be returned within 15 days unless marked final sale. Damaged items must be reported within 7 days with photos. Refunds above $200 require human approval. Electronics must include original packaging.',encoding='utf-8')
(KB/'shipping_policy.txt').write_text('ShopSphere Shipping Policy\nStandard delivery is 3 to 5 business days. Express delivery is 1 to 2 business days in major cities. If delivery is delayed beyond the promised date, customers may receive a goodwill coupon depending on order value and loyalty tier.',encoding='utf-8')
(KB/'refund_policy.txt').write_text('ShopSphere Refund Policy\nApproved refunds are processed to the original payment method within 5 to 7 business days. COD refunds are processed to wallet or bank account after verification. Refund requests above $200 require manual review.',encoding='utf-8')
(KB/'seller_image_policy.txt').write_text('ShopSphere Seller Image Policy\nProduct images must be clear, high resolution, and show the actual item. Blurry, watermarked, misleading, prohibited, or damaged-product images may be rejected automatically.',encoding='utf-8')
(KB/'inventory_guardrails.txt').write_text('ShopSphere Inventory Agent Guardrails\nAgents may recommend purchase orders automatically below $5,000. Orders between $5,000 and $25,000 require manager approval. Orders above $25,000 require finance approval. Agents cannot change price by more than 10% without human approval.',encoding='utf-8')

# product images via PIL
try:
    from PIL import Image, ImageDraw, ImageFilter
    labels=[]
    img_cats=['clean','blurry','damaged','watermark','wrong_background']
    colors={'Shoes':(80,150,220),'Apparel':(230,90,120),'Electronics':(80,80,80),'Home':(180,120,80),'Beauty':(220,140,200),'Sports':(80,180,120),'Books':(160,120,60),'Accessories':(120,120,200)}
    for idx,p in enumerate(products[:250],1):
        label=random.choice(img_cats) if idx>100 else 'clean'
        img=Image.new('RGB',(224,224),(245,245,245)); draw=ImageDraw.Draw(img)
        c=colors[p['category']]
        draw.rounded_rectangle([45,65,180,160], radius=18, fill=c, outline=(40,40,40), width=3)
        draw.text((55,92),p['category'][:10],fill=(255,255,255))
        draw.text((55,112),p['sku'],fill=(255,255,255))
        if label=='blurry': img=img.filter(ImageFilter.GaussianBlur(radius=3))
        if label=='damaged':
            draw=ImageDraw.Draw(img); draw.line([50,70,180,160],fill=(255,0,0),width=6); draw.line([180,70,50,160],fill=(255,0,0),width=6)
        if label=='watermark':
            draw=ImageDraw.Draw(img); draw.text((30,105),'SHOPSPHERE DEMO',fill=(0,0,0))
        if label=='wrong_background':
            img=Image.new('RGB',(224,224),(30,30,30)); draw=ImageDraw.Draw(img); draw.ellipse([65,65,160,160],fill=c); draw.text((70,105),'DARK BG',fill=(255,255,255))
        fname=f"{p['product_id']}_{label}.png"; img.save(IMG/fname)
        labels.append({'image_file':fname,'product_id':p['product_id'],'label':label,'acceptable_flag':1 if label=='clean' else 0})
    write_csv('product_image_labels.csv', labels)
except Exception as e:
    print('Image generation skipped',e)
