# ShopSphere AI Lab Dataset

Synthetic e-commerce dataset designed for TheMindRise.AI masterclass hands-on videos. It follows one fictional company, ShopSphere, across the full AI staircase: data, data engineering, data science, ML, deep learning, NLP, GenAI, RAG, and Agentic AI.

## Contents

- `data/customers.csv` — customer profile and channel behavior
- `data/products.csv` — product catalog with category, price and image path
- `data/orders.csv` — order-level transaction facts
- `data/order_items.csv` — order item details by SKU
- `data/clickstream.csv` — session and event behavior for RNN sequence demos
- `data/reviews.csv` — review text with sentiment and issue labels for NLP
- `data/support_tickets.csv` — support messages with issue type and urgency
- `data/inventory.csv` — inventory levels and stockout-risk target
- `data/daily_sales.csv` — SKU daily sales for LSTM/time-series demos
- `data/product_image_labels.csv` — labels for synthetic product image CNN demo
- `product_images/` — synthetic image classification data
- `knowledge_base/` — policy documents for RAG and Agentic AI demos
- `generate_shopsphere_dataset.py` — generator script to regenerate/extend the dataset

## Suggested Hands-on Videos

1. Classification: predict return or churn using `customers`, `orders`, and `support_tickets`.
2. CNN: classify product image quality using `product_images` and `product_image_labels.csv`.
3. RNN: predict next session action or purchase likelihood using `clickstream.csv`.
4. LSTM: forecast SKU demand using `daily_sales.csv`.
5. NLP: sentiment and issue classification using `reviews.csv` and `support_tickets.csv`.
6. GenAI: generate product descriptions from `products.csv`.
7. RAG: answer customer policy questions using `knowledge_base`.
8. Agentic AI: inventory monitoring and purchase-order recommendation using `inventory.csv`, `daily_sales.csv`, and `knowledge_base/inventory_guardrails.txt`.

## Important Note

All data is synthetic and created for education. It does not represent real customers, real orders, or real company operations.
